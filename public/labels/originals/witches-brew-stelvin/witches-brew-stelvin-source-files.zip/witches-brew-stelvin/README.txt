Leelanau Cellars Central - Label Source Package

This package contains the original label production/source files supplied for Central, including applicable INDD, IDML, PDF, QR artwork, or EPS files.

Packaged font files are intentionally not redistributed. Large linked support-art duplicates were also omitted from the web bundle to keep Central deployment storage manageable. The primary source documents and final label PDFs are preserved here.
