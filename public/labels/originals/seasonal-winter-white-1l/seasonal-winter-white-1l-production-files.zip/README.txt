Winter White 1L - Central production download

Included:
- Original Illustrator artwork supplied to Leelanau Cellars
- Optimized production PDF for easy viewing/reference
- Original package report

Not included in Central:
- Packaged font files
- Large linked PSD support artwork

Those support assets are intentionally excluded from the Central deployment to keep the application deployable and avoid redistributing font files.
